[![built-with-azurra-framework](https://github.com/Elbullazul/Azurra_framework/raw/assets/azurra_framework_smaller.png)](https://github.com/Elbullazul/Azurra_framework)

# Mac OS 9 'Sonata'

The classic look of Mac OS 9, now for GTK 3 desktops

![mac-os-9-classic](https://github.com/B00merang-Project/gallery/raw/master/Mac%20OS%209%20Classic%20(3).png)

**Maintainer :** [Elbullazul](https://github.com/Elbullazul)

**Distributor :** [B00merang Project](https://github.com/B00merang-Project)

**License :** GPL v3

**More info :** http://b00merang.weebly.com/mac-os-9.html

### Manual installation

Extract the zip file to the themes directory i.e. `/home/USERNAME/.themes`

### Requirements

- GTK+ 3.20 or above
- Murrine and Pixmap theme engines

### Contribute

Contact us @ http://b00merang.weebly.com/contact.html
